from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional, Union

import torch

from sglang.srt.layers.attention.base_attn_backend import AttentionBackend
from sglang.srt.layers.attention.moba.moba_prefill import moba_attn_varlen
from sglang.srt.model_executor.forward_batch_info import ForwardBatch, ForwardMode
from sglang.srt.speculative.spec_info import SpecInput
from sglang.srt.utils import get_compiler_backend

if TYPE_CHECKING:
    from sglang.srt.layers.radix_attention import RadixAttention
    from sglang.srt.model_executor.model_runner import ModelRunner

from sgl_kernel.flash_attn import flash_attn_with_kvcache


@dataclass
class MixtureBlockAttentionMetadata:
    """Metadata to be init once in the model forward pass,
    each layer's forward pass can reuse the metadata.

    For each init metadata function, we will try set up them in below order
    """

    # Sequence lengths for the forward batch
    cache_seqlens_int32: torch.Tensor = None
    # Maximum sequence length for query
    max_seq_len_q: int = 1
    # Maximum sequence length for key
    max_seq_len_k: int = 0
    # Cumulative sequence lengths for query
    cu_seqlens_q: torch.Tensor = None
    # Cumulative sequence lengths for key
    cu_seqlens_k: torch.Tensor = None
    # Window size (typically used by Gemma)
    window_size: tuple = (-1, -1)
    # Page table, the index of KV Cache Tables/Blocks
    page_table: torch.Tensor = None
    use_moba: bool = False
    update_block_cache: bool = False


class MixtureBlockAttentionBackend(AttentionBackend):
    """MixtureAttention backend implementation.

    Note about the init:
    - If no spec decoding
        - MixtureAttentionBackend will be init once when the server starts.

    Note about CUDA Graph:
    - We don't support CUDA Graph
    """

    def __init__(
        self,
        model_runner: ModelRunner,
        skip_prefill: bool = False,
        speculative_step_id=0,
        topk=0,
        speculative_num_steps=0,
    ):
        super().__init__()

        assert not (
            model_runner.sliding_window_size is not None
            and model_runner.model_config.is_encoder_decoder
        ), "Sliding window and cross attention are not supported together"
        self.forward_metadata: MixtureBlockAttentionMetadata = None
        # extra metadata for handling speculative decoding topk > 1, extended draft decode and verify
        self.forward_metadata_spec_decode_expand: MixtureBlockAttentionMetadata = None
        self.max_context_len = model_runner.model_config.context_len
        self.device = model_runner.device
        self.decode_cuda_graph_metadata = {}
        self.target_verify_metadata = {}
        self.req_to_token = model_runner.req_to_token_pool.req_to_token
        self.kv_cache_dtype = model_runner.kv_cache_dtype
        self.kv_cache_dtype_str = model_runner.server_args.kv_cache_dtype
        self.page_size = model_runner.page_size
        self.use_moba_decode = getattr(
            model_runner.model_config.hf_config, "use_moba_decode", False
        )
        assert self.page_size == int(
            model_runner.model_config.hf_config.moba_block_size
        ), f"page_size should be equal to moba_block_size in moba_backend. Now, page_size = {self.page_size} and moba_block_size = {model_runner.model_config.hf_config.moba_block_size}"
        self.moba_block_size = int(model_runner.model_config.hf_config.moba_block_size)
        self.moba_topk = int(model_runner.model_config.hf_config.moba_topk)
        if isinstance(model_runner.model_config.hf_config.moba_layer_freq, int):
            self.moba_layer_freq = [
                (
                    1
                    if not (
                        (i + 1) % model_runner.model_config.hf_config.moba_layer_freq
                        == 0
                    )
                    else 0
                )
                for i in range(model_runner.model_config.hf_config.num_hidden_layers)
            ]
        else:
            self.moba_layer_freq = model_runner.model_config.hf_config.moba_layer_freq

    def init_forward_metadata(self, forward_batch: ForwardBatch):
        """Initialize forward metadata hence all layers in the forward pass can reuse it."""
        metadata = MixtureBlockAttentionMetadata()
        seqlens_in_batch = forward_batch.seq_lens
        batch_size = forward_batch.batch_size
        device = seqlens_in_batch.device

        if forward_batch.forward_mode.is_decode_or_idle():
            # Draft Decode
            # Normal Decode
            if (
                seqlens_in_batch.max().item()
                > (self.moba_topk - 1) * self.moba_block_size
            ):
                metadata.use_moba = True
            else:
                metadata.use_moba = False
            if (seqlens_in_batch % self.moba_block_size).min().item() == 0:
                metadata.update_block_cache = True
            else:
                metadata.update_block_cache = False
            metadata.cache_seqlens_int32 = seqlens_in_batch.to(torch.int32)
            moba_seqlens_in_batch = torch.min(
                seqlens_in_batch % self.page_size
                + (self.moba_topk - 1) * self.moba_block_size,
                seqlens_in_batch,
            )
            metadata.max_seq_len_k = forward_batch.seq_lens.max().item()
            metadata.cu_seqlens_q = torch.arange(
                0, batch_size + 1, dtype=torch.int32, device=device
            )
            metadata.cu_seqlens_k = torch.nn.functional.pad(
                torch.cumsum(moba_seqlens_in_batch, dim=0, dtype=torch.int32), (1, 0)
            )
            metadata.page_table = forward_batch.req_to_token_pool.req_to_token[
                forward_batch.req_pool_indices, : metadata.max_seq_len_k
            ]

        elif forward_batch.forward_mode.is_extend_or_draft_extend_or_mixed():
            metadata.cache_seqlens_int32 = seqlens_in_batch.to(torch.int32)
            metadata.max_seq_len_k = forward_batch.seq_lens.max().item()
            metadata.cu_seqlens_k = torch.nn.functional.pad(
                torch.cumsum(seqlens_in_batch, dim=0, dtype=torch.int32), (1, 0)
            )
            metadata.page_table = forward_batch.req_to_token_pool.req_to_token[
                forward_batch.req_pool_indices, : metadata.max_seq_len_k
            ]

            if (
                any(forward_batch.extend_prefix_lens_cpu)
                or forward_batch.forward_mode == ForwardMode.DRAFT_EXTEND
            ):
                extend_seq_lens = forward_batch.extend_seq_lens
                metadata.max_seq_len_q = max(forward_batch.extend_seq_lens_cpu)
                metadata.cu_seqlens_q = torch.nn.functional.pad(
                    torch.cumsum(extend_seq_lens, dim=0, dtype=torch.int32), (1, 0)
                )
            else:
                metadata.max_seq_len_q = metadata.max_seq_len_k
                metadata.cu_seqlens_q = metadata.cu_seqlens_k

        # Convert the page table to a strided format which is needed by FA3 API
        if self.page_size > 1:
            self.strided_indices = torch.arange(
                0, metadata.page_table.shape[1], self.page_size, device=self.device
            )
            metadata.page_table = (
                metadata.page_table[:, self.strided_indices] // self.page_size
            )

        self.forward_metadata = metadata

    def forward_extend(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        layer: RadixAttention,
        forward_batch: ForwardBatch,
        save_kv_cache=True,
        # For multi-head latent attention
        q_rope: Optional[torch.Tensor] = None,
        k_rope: Optional[torch.Tensor] = None,
    ):
        if k is not None:
            assert v is not None
            if save_kv_cache:
                cache_loc = (
                    forward_batch.out_cache_loc
                    if not layer.is_cross_attention
                    else forward_batch.encoder_out_cache_loc
                )
                forward_batch.token_to_kv_pool.set_kv_buffer(
                    layer, cache_loc, k, v, layer.k_scale, layer.v_scale
                )

        # Use precomputed metadata across all layers
        metadata = self.forward_metadata

        # Calculate window size (can be moved to metadata if layer properties don't change)
        # we don't do layer.sliding_window_size - 1 since in model.get_attention_sliding_window_size() we already - 1
        # here is two side inclusive
        window_size = (
            (layer.sliding_window_size, 0)
            if layer.sliding_window_size is not None and layer.sliding_window_size > -1
            else (-1, -1)
        )
        k_descale, v_descale = None, None
        # only use kv scaling if: 1) fp8 kv is explicitly enabled, 2) RadixAttention
        # has corresponding quantization method so that layer.k_scale is not None
        if self.kv_cache_dtype_str != "auto" and layer.k_scale is not None:
            descale_shape = (forward_batch.batch_size, layer.tp_k_head_num)
            k_descale = layer.k_scale.expand(descale_shape)
            v_descale = layer.v_scale.expand(descale_shape)
            q = q.to(self.kv_cache_dtype)
        causal = not layer.is_cross_attention

        page_table = metadata.page_table
        cu_seqlens_q = metadata.cu_seqlens_q
        cache_seqlens = metadata.cache_seqlens_int32
        max_seqlen_q = metadata.max_seq_len_q
        max_seqlen_k = metadata.max_seq_len_k
        cu_seqlens_k = metadata.cu_seqlens_k

        moba_topk = self.moba_topk
        moba_block_size = self.moba_block_size
        moba_layer_freq = self.moba_layer_freq
        # Use Flash Attention for prefill
        if (
            max_seqlen_k
            > moba_block_size  # Save block token when max_seqlen_k > moba_block_size
            and forward_batch.forward_mode.is_extend()
            and (moba_layer_freq[layer.layer_id] == 1)
            and (not any(forward_batch.extend_prefix_lens_cpu))
        ):
            q = q.contiguous().view(-1, layer.tp_q_head_num, layer.head_dim)
            result, key_gate_weight = moba_attn_varlen(
                q=q,
                k=k,
                v=v,
                cu_seqlens=cu_seqlens_q,
                max_seqlen=max_seqlen_q,
                moba_chunk_size=moba_block_size,
                moba_topk=moba_topk,
            )
            if save_kv_cache:
                cache_loc = (
                    forward_batch.out_cache_loc
                    if not layer.is_cross_attention
                    else forward_batch.encoder_out_cache_loc
                )
                cache_loc = torch.unique((cache_loc / self.page_size).to(torch.int32))[
                    : key_gate_weight.shape[0]
                ]
                forward_batch.token_to_kv_pool.set_block_buffer(
                    layer, cache_loc, key_gate_weight, layer.k_scale
                )
        else:
            # Fallback to FA3
            key_cache, value_cache = forward_batch.token_to_kv_pool.get_kv_buffer(
                layer.layer_id
            )
            key_cache = key_cache.view(
                -1, self.page_size, layer.tp_k_head_num, layer.head_dim
            )
            value_cache = value_cache.view(
                -1, self.page_size, layer.tp_v_head_num, layer.head_dim
            )
            q_reshaped = q.contiguous().view(-1, layer.tp_q_head_num, layer.head_dim)

            # Default: single-token self-attention
            result = flash_attn_with_kvcache(
                q=q_reshaped,
                k_cache=key_cache,
                v_cache=value_cache,
                page_table=page_table,
                cache_seqlens=cache_seqlens,
                cu_seqlens_q=metadata.cu_seqlens_q,
                cu_seqlens_k_new=cu_seqlens_k,
                max_seqlen_q=max_seqlen_q,
                softmax_scale=layer.scaling,
                causal=causal,
                window_size=window_size,
                softcap=layer.logit_cap,
                k_descale=k_descale,
                v_descale=v_descale,
                return_softmax_lse=False,
            )
        return result.view(-1, layer.tp_q_head_num * layer.v_head_dim)

    def forward_decode(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        layer: RadixAttention,
        forward_batch: ForwardBatch,
        save_kv_cache=True,
        # For multi-head latent attention
        q_rope: Optional[torch.Tensor] = None,
        k_rope: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        if k is not None:
            assert v is not None
            if save_kv_cache:
                cache_loc = (
                    forward_batch.out_cache_loc
                    if not layer.is_cross_attention
                    else forward_batch.encoder_out_cache_loc
                )
                forward_batch.token_to_kv_pool.set_kv_buffer(
                    layer, cache_loc, k, v, layer.k_scale, layer.v_scale
                )

        # Use precomputed metadata across all layers
        metadata = self.forward_metadata

        # Calculate window size (can be moved to metadata if layer properties don't change)
        # we don't do layer.sliding_window_size - 1 since in model.get_attention_sliding_window_size() we already - 1
        # here is two side inclusive
        window_size = (
            (layer.sliding_window_size, 0)
            if layer.sliding_window_size is not None and layer.sliding_window_size > -1
            else (-1, -1)
        )

        k_descale, v_descale = None, None
        # only use kv scaling if: 1) fp8 kv is explicitly enabled, 2) RadixAttention
        # has corresponding quantization method so that layer.k_scale is not None
        if self.kv_cache_dtype_str != "auto":
            if layer.k_scale is not None:
                descale_shape = (forward_batch.batch_size, layer.tp_k_head_num)
                k_descale = layer.k_scale.expand(descale_shape)
                v_descale = layer.v_scale.expand(descale_shape)
            q = q.to(self.kv_cache_dtype)
        key_cache, value_cache = forward_batch.token_to_kv_pool.get_kv_buffer(
            layer.layer_id
        )
        key_cache = key_cache.view(
            -1, self.page_size, layer.tp_k_head_num, layer.head_dim
        )
        value_cache = value_cache.view(
            -1, self.page_size, layer.tp_v_head_num, layer.head_dim
        )
        block_cache = forward_batch.token_to_kv_pool.get_block_buffer(layer.layer_id)
        block_cache = block_cache.view(-1, 1, layer.tp_v_head_num, layer.head_dim)

        page_table = metadata.page_table
        cache_seqlens = metadata.cache_seqlens_int32
        cu_seqlens_k = metadata.cu_seqlens_k
        max_seqlen_q = metadata.max_seq_len_q
        moba_topk = self.moba_topk
        moba_block_size = self.moba_block_size
        moba_layer_freq = self.moba_layer_freq
        q_reshaped = q.contiguous().view(-1, layer.tp_q_head_num, layer.head_dim)
        # print(page_table)
        # mean pool the last key block in one batch and update its block token to block cache
        last_block_index = (
            cache_seqlens - 1
        ) // self.page_size  # obtain the last block index in one batch
        if metadata.update_block_cache and self.use_moba_decode:
            block_cache_loc = page_table.gather(
                1, last_block_index.view(-1, 1).to(torch.int64)
            )
            block_token = key_cache[block_cache_loc].mean(2).squeeze(1)
            forward_batch.token_to_kv_pool.set_block_buffer(
                layer, block_cache_loc.view(-1), block_token, layer.k_scale
            )

        # use MoBA
        if self.use_moba_decode:
            if (moba_layer_freq[layer.layer_id] == 1) and metadata.use_moba:
                # calculate MoBA gate
                key_gate_weight = (
                    block_cache[page_table].squeeze(2).float()
                )  # [batch_size, block_num, tp_k_head_num, head_dim]
                query_gate_weight = (
                    q_reshaped.unsqueeze(1).mean(2, keepdim=True).float()
                )  # query_gate_weight head must equal to tp_k_head_num and tp_k_head_num = 1
                gate = torch.matmul(
                    key_gate_weight, query_gate_weight.transpose(-1, -2)
                )
                batch_size, block_num, head_num, _ = gate.shape
                block_ids = torch.arange(block_num, device=gate.device).unsqueeze(0)
                padding_mask = (
                    (block_ids > last_block_index.unsqueeze(1))
                    .unsqueeze(-1)
                    .unsqueeze(-1)
                )
                last_block_mask = (
                    (block_ids == last_block_index.unsqueeze(1))
                    .unsqueeze(-1)
                    .unsqueeze(-1)
                )
                batch_mask = (cache_seqlens < moba_topk * moba_block_size).view(
                    -1, 1, 1, 1
                )
                gate = gate.masked_fill(
                    padding_mask, -torch.inf
                )  # remove padding block
                gate = gate.masked_fill(
                    last_block_mask, torch.inf
                )  # forcing to select the last block
                gate = gate.masked_fill(
                    batch_mask, 0
                )  # remove short sequence in one batch
                page_table_index = (
                    gate.topk(min(moba_topk, block_num), dim=1)[1]
                    .view(gate.shape[0], -1)
                    .sort(dim=1)[0]
                )

                # update page table
                page_table = page_table.gather(1, page_table_index)
                cache_seqlens = cu_seqlens_k[1:] - cu_seqlens_k[:-1]
            else:
                cu_seqlens_k = torch.nn.functional.pad(
                    torch.cumsum(cache_seqlens, dim=0, dtype=torch.int32), (1, 0)
                )

        # Default: single-token self-attention
        result = flash_attn_with_kvcache(
            q=q_reshaped,
            k_cache=key_cache,
            v_cache=value_cache,
            page_table=page_table,
            cache_seqlens=cache_seqlens,
            cu_seqlens_q=metadata.cu_seqlens_q,
            cu_seqlens_k_new=cu_seqlens_k,
            max_seqlen_q=max_seqlen_q,
            softmax_scale=layer.scaling,
            causal=True,
            window_size=window_size,
            softcap=layer.logit_cap,
            k_descale=k_descale,
            v_descale=v_descale,
            return_softmax_lse=False,
        )
        return result.view(-1, layer.tp_q_head_num * layer.v_head_dim)

    def init_cuda_graph_state(self, max_bs: int, max_num_tokens: int):
        """Initialize CUDA graph state for the attention backend.

        Args:
            max_bs (int): Maximum batch size to support in CUDA graphs

        This creates fixed-size tensors that will be reused during CUDA graph replay
        to avoid memory allocations.
        """
        # This is being used by normal decode and draft decode when topk == 1
        self.decode_cuda_graph_metadata = {
            "cache_seqlens": torch.zeros(max_bs, dtype=torch.int32, device=self.device),
            "cu_seqlens_q": torch.arange(
                0, max_bs + 1, dtype=torch.int32, device=self.device
            ),
            "cu_seqlens_k": torch.zeros(
                max_bs + 1, dtype=torch.int32, device=self.device
            ),
            "page_table": torch.zeros(
                max_bs,
                (self.max_context_len + self.page_size - 1) // self.page_size,
                dtype=torch.int32,
                device=self.device,
            ),
            "strided_indices": torch.arange(
                0, self.max_context_len, self.page_size, device=self.device
            ),
        }

    def init_forward_metadata_capture_cuda_graph(
        self,
        bs: int,
        num_tokens: int,
        req_pool_indices: torch.Tensor,
        seq_lens: torch.Tensor,
        encoder_lens: Optional[torch.Tensor],
        forward_mode: ForwardMode,
        spec_info: Optional[SpecInput],
    ):
        """Initialize forward metadata for capturing CUDA graph."""
        metadata = MixtureBlockAttentionMetadata()

        device = seq_lens.device
        if forward_mode.is_decode_or_idle():
            # Normal Decode
            # Get sequence information
            metadata.cache_seqlens_int32 = seq_lens.to(torch.int32)
            moba_cache_seqlens_int32 = torch.min(
                seq_lens.to(torch.int32) % self.page_size
                + (self.moba_topk - 1) * self.moba_block_size,
                seq_lens.to(torch.int32),
            )
            batch_size = len(seq_lens)
            device = seq_lens.device
            metadata.cu_seqlens_k = torch.nn.functional.pad(
                torch.cumsum(moba_cache_seqlens_int32, dim=0, dtype=torch.int32), (1, 0)
            )
            metadata.moba_cache_seqlens_int32 = moba_cache_seqlens_int32
            # Precompute maximum sequence length
            metadata.max_seq_len_k = seq_lens.max().item()
            # Precompute page table
            metadata.page_table = self.decode_cuda_graph_metadata["page_table"][
                req_pool_indices, :
            ]
            # Precompute cumulative sequence lengths
            metadata.cu_seqlens_q = torch.arange(
                0, batch_size + 1, dtype=torch.int32, device=device
            )
            if seq_lens.max().item() > (self.moba_topk - 1) * self.moba_block_size:
                metadata.use_moba = True
            else:
                metadata.use_moba = False
            if (seq_lens % self.moba_block_size).min().item() == 0:
                metadata.update_block_cache = True
            else:
                metadata.update_block_cache = False
            self.decode_cuda_graph_metadata[
                (int(metadata.use_moba), int(metadata.update_block_cache), bs)
            ] = metadata
        self.forward_metadata = metadata

    def init_forward_metadata_replay_cuda_graph(
        self,
        bs: int,
        req_pool_indices: torch.Tensor,
        seq_lens: torch.Tensor,
        seq_lens_sum: int,
        encoder_lens: Optional[torch.Tensor],
        forward_mode: ForwardMode,
        spec_info: Optional[Union[EagleDraftInput, EagleVerifyInput]],
        seq_lens_cpu: Optional[torch.Tensor],
        out_cache_loc: torch.Tensor = None,
    ):
        """Initialize forward metadata for replaying CUDA graph."""
        seq_lens = seq_lens[:bs]
        seq_lens_cpu = seq_lens_cpu[:bs]
        req_pool_indices = req_pool_indices[:bs]
        device = seq_lens.device
        metadata = None
        metadata_expand = None
        if seq_lens.max().item() > (self.moba_topk - 1) * self.moba_block_size:
            is_moba = 1
        else:
            is_moba = 0
        if (seq_lens % self.moba_block_size).min().item() == 0:
            update_block_cache = 1
        else:
            update_block_cache = 0

        if forward_mode.is_decode_or_idle():
            # Normal Decode
            metadata = self.decode_cuda_graph_metadata[
                (is_moba, update_block_cache, bs)
            ]
            max_len = seq_lens.max().item()
            max_seq_pages = (max_len + self.page_size - 1) // self.page_size
            metadata.max_seq_len_k = max_len
            normal_decode_set_metadata(
                metadata,
                self.req_to_token,
                req_pool_indices,
                self.decode_cuda_graph_metadata["strided_indices"],
                max_seq_pages,
                seq_lens,
                self.page_size,
                self.moba_block_size,
                self.moba_topk,
            )

        self.forward_metadata = metadata

    def get_cuda_graph_seq_len_fill_value(self):
        """Get the fill value for sequence length in CUDA graph."""
        return 4

    def get_cuda_graph_seq_len_fill_value_update_block_cache(self):
        """Get the fill value for sequence length in CUDA graph."""
        return self.moba_block_size

    def get_cuda_graph_seq_len_fill_value_long(self):
        return (self.moba_topk - 1) * self.moba_block_size + 1

    def get_cuda_graph_seq_len_fill_value_long_update_block_cache(self):
        return self.moba_topk * self.moba_block_size


@torch.compile(dynamic=True, backend=get_compiler_backend())
def normal_decode_set_metadata(
    metadata,
    req_to_token,
    req_pool_indices,
    strided_indices,
    max_seq_pages,
    seq_lens,
    page_size,
    moba_block_size,
    moba_topk,
):
    metadata.cache_seqlens_int32 = seq_lens.to(torch.int32)
    moba_cache_seqlens_int32 = torch.min(
        seq_lens.to(torch.int32) % page_size + (moba_topk - 1) * moba_block_size,
        seq_lens.to(torch.int32),
    )
    # moba_cache_seqlens_int32 = seq_lens.to(torch.int32)
    metadata.moba_cache_seqlens_int32 = moba_cache_seqlens_int32
    metadata.cu_seqlens_k[1:].copy_(
        torch.cumsum(moba_cache_seqlens_int32, dim=0, dtype=torch.int32)
    )
    page_indices = req_to_token[
        req_pool_indices[:, None],
        strided_indices[:max_seq_pages][None, :],
    ]
    metadata.page_table[:, :max_seq_pages].copy_(page_indices // page_size)
    metadata.page_table[:, max_seq_pages:].fill_(0)
